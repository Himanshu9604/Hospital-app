// src/components/IpdPatients.js
import React from 'react';

function IpdPatients() {
  return (
    <div>
      <h2>IPD Patients</h2>
      <p>Details of IPD Patients.</p>
    </div>
  );
}

export default IpdPatients;
