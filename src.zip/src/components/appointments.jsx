// src/components/Appointments.js
import React from 'react';

function Appointments() {
  return (
    <div>
      <h2>Appointments</h2>
      <p>List of upcoming appointments.</p>
    </div>
  );
}

export default Appointments;
